package com.example.bansi.practical_firebase;

public class Database{
    public String uname;
    public String pass;
    public Database(){

    }
    public Database(String uname, String pass){
        this.uname=uname;
        this.pass=pass;
    }
}

