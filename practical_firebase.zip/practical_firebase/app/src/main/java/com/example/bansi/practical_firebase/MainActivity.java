package com.example.bansi.practical_firebase;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MainActivity extends AppCompatActivity {
    TextView u;
    TextView p;
    Button o;
    FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference myRef = database.getReference();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        u=findViewById(R.id.username);
        p=findViewById(R.id.password);
        o=findViewById(R.id.ok);

    }
    public void add(View view){
        String text1 = u.getText().toString();
        String text2 = p.getText().toString();
        Database db = new Database(text1,text2);
        myRef.child(text1).setValue(db);
    }
    public void retrive(View view){
    /*    final String text1 = u.getText().toString();
        String text2 = p.getText().toString();
        myRef.child("url/values").addListenerForSingleValueEvent(new ValueEventListener() {
            DatabaseReference x = myRef.child(text1).child("uname");
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                String email=dataSnapshot.getValue(String.class);
                Toast.makeText(MainActivity.this,email+"",Toast.LENGTH_SHORT).show();


                }
            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });*/

    }
}
